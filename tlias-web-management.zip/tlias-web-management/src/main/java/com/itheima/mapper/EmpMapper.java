package com.itheima.mapper;

import com.itheima.pojo.Emp;
import org.apache.ibatis.annotations.*;

import java.time.LocalDate;
import java.util.List;

@Mapper
public interface EmpMapper {
//    /*
//      查询总记录数
//     */
//    @Select("select count(*) from emp")
//    public Long count();
//    /*
//     分页查询 获取页面数据列表
//    */
//    @Select("select * from emp limit #{start},#{pageSize}")
//    public List<Emp> page(Integer start, Integer pageSize);

//  上面是原始的分页查询方法，现在基于PageHelper插件
    //员工信息查询
    @Select("select * from emp")
    public List<Emp> page();

    //条件查询员工
    //@Select("select * from emp where name = #{name} and gender = #{gender} and  entrydate between #{begin} and #{end} ;")
    //使用xml文件编写动态条件查询sql
    public List<Emp> list(String name, Short gender, LocalDate begin, LocalDate end);

    //删除员工
    //使用xml文件编写动态删除sql
    void delete(List<Integer> ids);

    //新增员工
    @Insert("insert into emp(username, name, gender, image, job, entrydate, dept_id, create_time, update_time) " +
            " values(#{username},#{name},#{gender},#{image},#{job},#{entrydate},#{deptId},#{createTime},#{updateTime})")
    void insert(Emp emp);

    //根据id查找员工
    @Select("select * from emp where id = #{id}")
    Emp getById(Integer id);

    //修改员工信息
    //使用xml文件编写动态更新sql
    void update(Emp emp);

    @Delete("delete from emp where dept_id = #{id}")
    void deleteByDeptId(Integer id);
}
