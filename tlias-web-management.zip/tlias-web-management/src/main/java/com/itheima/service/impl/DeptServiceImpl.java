package com.itheima.service.impl;

import com.itheima.mapper.DeptMapper;
import com.itheima.mapper.EmpMapper;
import com.itheima.pojo.Dept;
import com.itheima.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class DeptServiceImpl implements DeptService {
    @Autowired
    private DeptMapper deptMapper;
    @Autowired
    private EmpMapper empMapper;

    //查询：显示所有部门
    @Override
    public List<Dept> list() {
        return deptMapper.list();
    }
    //删除部门
    @Override
    @Transactional(rollbackFor = Exception.class) //默认是只有运行时异常才会回滚，
                                                // 配置rollbackFor = Exception.class指定出现何种异常类型才回滚事务，
                                                 //这里Exception.class代表所有异常
    public void delete(Integer id) {
        deptMapper.deleteById(id); //根据id删除部门数据
        //删除了部门---->部门下对应的员工也要删除
        empMapper.deleteByDeptId(id);
    }
    //新增部门
    @Override
    public void add(Dept dept) {
        dept.setCreateTime(LocalDateTime.now());
        dept.setUpdateTime(LocalDateTime.now());
        deptMapper.insert(dept);
    }
    //根据id查询
    @Override
    public Dept getById(Integer id) {

        return deptMapper.getById(id);
    }
   //修改部门信息
    @Override
    public void update(Dept dept) {
        dept.setUpdateTime(LocalDateTime.now());
        deptMapper.updateById(dept);

    }
}
